npm install && npm run test

